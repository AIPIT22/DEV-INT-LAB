For this chapter, the a sketch that implements every step described in the 
book is included. This is because the figures and steps used to develop the 
code don't really line up (there are more steps than figures). Each sketch 
has a name like step15_framerate, which should be self-explanatory when used 
with the book. (I do not recommend using this ugly style of naming for your
 own sketches, it's done this way simply because the step/figure numbering 
is relevant and needs to be included). 

All examples have been tested but if you find errors of any kind (typos, 
unused variables, profanities in the comments, the usual), please contact 
me through http://benfry.com/writing and I'll be happy to fix the code.

The code in this file is (c) 2008 Ben Fry. Rights to use of the code can be 
found in the preface of "Visualizing Data".
